package com.poly.sneaker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SneakerApplicationTests {

	@Test
	void contextLoads() {
	}

}
