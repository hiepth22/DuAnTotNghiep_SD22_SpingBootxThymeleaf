package com.poly.sneaker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SneakerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SneakerApplication.class, args);
	}

}
